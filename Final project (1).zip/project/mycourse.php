<?php include('nav01.php');?>

<!DOCTYPE html>

<html>
<head>

<title> Course information Page  </title>
<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<link rel="stylesheet" type="text/css" href="homepage.css">
</head> 
 <body>
    <div class="ww">
    <h1 align="center"> Class Information </h1>
    
</div><br><br>
<div class="bb">
<table align ="center" border="1" style="border-collapse:collapse"> 
<tr>
<th>Course ID</th>
<th>Course Name</th>
<th>Day</th>
<th>Room No</th>
<th>Time</th>


</tr>

<tr>
    <td>3001</td>
    <td>Web Technologies</td>
    <td>Sunday</td>
    <td>5001</td>
    <td>8:00am -11:00am</td>
  </tr>

<tr>
    <td>4001</td>
    <td>Object Oriented Program 2</td>
    <td>Sunday</td>
    <td>5001</td>
    <td>2:00pm -5:00pm</td>
  </tr>

<tr>
    <td>2101</td>
    <td>Object Oriented Program 1</td>
    <td>Monday</td>
    <td>3111</td>
    <td>2:00pm -5:00pm</td>

  </tr><tr>
<td>2101</td>
    <td>Object Oriented Program 1</td>
    <td>Monday</td>
    <td>3111</td>
    <td>12:00pm -2:00pm</td></tr>
    <tr>
    <td>3001</td>
    <td>Web Technologies</td>
    <td>Sunday</td>
    <td>5001</td>
    <td>8:00am -11:00am</td>
  </tr>

<tr>
    <td>4001</td>
    <td>Object Oriented Program 2</td>
    <td>Sunday</td>
    <td>5001</td>
    <td>2:00pm -5:00pm</td>
  </tr>

<tr>
    <td>2101</td>
    <td>Object Oriented Program 1</td>
    <td>Monday</td>
    <td>3111</td>
    <td>2:00pm -5:00pm</td>

  </tr><tr>
<td>2101</td>
    <td>Object Oriented Program 1</td>
    <td>Monday</td>
    <td>3111</td>
    <td>12:00pm -2:00pm</td></tr>
</table></div>

</button><br><br>
<button><a href="facultylog.php">logout</a></button></h2>
</body></html>