<?php include('navbar.php');?>
<!DOCTYPE HTML>
<html>  
<head>


<title>Application</title>
<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
</head>
<h1 align='center'><i>Please choose your desire program</i> </h1>
<table align='center'>

	<div class="bd">

<i><a href="ApplicationFormUndergraduate.php">Undergraduation</i>
</div>

	<div class="bd">

<i><a href="ApplicationFormGraduate.php">Graduation</i>
</div>




</h2>
<div class="bd">

	<i><a href="HomePage.php">Go To HomePage</i> 
	</div>




</html>
  <style>
    body{
background: url(a1.png);
background-attachment: fixed;
background-size: cover;
}

.bd
{ background-color: rgb(223, 227, 236);
opacity: .5;
border: 5px solid black;
height: 200px;
width: 400px;
margin: 5px;
padding: 5px 10px;
color: rgb(233, 233, 10);
font-size: 50px;
float:left;



}

  </style>