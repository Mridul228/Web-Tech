<?php include('navbar.php');?>

<html>


<head>
	<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<link rel="stylesheet" type="text/css" href="homepage.css">
	<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="about.css">
</head>

<body>
	<style>
    body{
background: url(a1.png);
background-attachment: fixed;
background-size: cover;
}

.bd
{ background-color: rgb(223, 227, 236);
opacity: .5;
border: 5px solid black;
height: 200px;
width: 400px;
margin: 5px;
padding: 5px 10px;
color: rgb(233, 233, 10);
font-size: 50px;
float:left;



}

  </style>


<div class="bd">
<a href="General.php">General Information</a></a>
</div>



<div class="bd">
<a href="Why.php">Why Study at UE</a></a>




</div>
<div class="bd">
<a href="Rules.php">Rule_Of_Entry</a></a>

</div>


<div class="bd">
<a href="Resource.php">Resource</a></a>

</div>
<div class="bd">
<a href="HomePage.php">Go To HomePage</a></div>
</body>
</html>