<!DOCTYPE HTML>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fac log Layout</title>

<link rel="stylesheet" type="text/css" href="homepage.css">

 <style>
* {
  box-sizing: border-box;
}

}</style>
</head>

<body>
<div class="link">
  <h3><p align="right">
<a href="faclog2nd.php">Dashboard     </a>
<p align="left">
<a href="studentinfo.php">Student Info</a>
<p align="right">
<a  href="facclass.php">Class Info</a>
<p align="Center">
<a href="ajax.php">Section info</a>
<a href="vprofile.php">View Profile</a>
<a style="float:right" href="login.php">Log out   </a>
<p align="left">
<br></h3></p></h3></div><br>

  </body>
  </html>
 