<!DOCTYPE HTML>
<html>  
<head>
<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<title>Applying</title>
</head>
<h1 align='center'>Choose academic course</h1>
<table align='center'>
<tr>
<td><a href="ApplicationFormGraduate.php"> Msc in Computer Science & Engineering</td>
</tr>
<tr>
<td><a href="ApplicationFormGraduate.php"> Msc in Electrical & Electronic Engineering</td>
</tr>
<tr>
<td><a href="ApplicationFormGraduate.php"> Masters in English</td>
</tr>
<tr>
<td><a href="ApplicationFormGraduate.php">Masters in Law</td>
</tr>
<tr>
<td><a href="ApplicationFormGraduate.php">Masters of Business Administration</td>

</tr>
</table>
</html>