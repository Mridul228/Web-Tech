<?php include('navbar.php');?>

<!DOCTYPE HTML>
<html>
<head></head>
<body>
  <style>
    body{
background: url(a1.png);
background-attachment: fixed;
background-size: cover;
}
  </style>

<div class="header">
<marquee direction="left" behavior="alternate"  >

<h1>University of Education</marquee></a></h1></div>
<h1>
  <div class="footer">
    <marquee direction="right" behavior="alternate"  >
-An Invesment in Knowledge pays the best interest</a></h1>
  <img src="77.jpg" width="60" height="60" title="Logo of a company" alt="Logo of a company" />
  
</marquee></a></div>

<marquee marquee direction="left" behavior="alternate"  bgcolor="white">



<img src="11.jpg" width="400" height="400" title="Logo of a company" alt="Logo of a company" />
<img src="66.jpg" width="400" height="400" title="Logo of a company" alt="Logo of a company" />
<img src="22.jpg" width="400" height="400" title="Logo of a company" alt="Logo of a company" />
<img src="33.jpg" width="400" height="400" title="Logo of a company" alt="Logo of a company" />
<img src="44.jpg" width="400" height="400" title="Logo of a company" alt="Logo of a company" />



<img src="55.jpg" width="400" height="400" title="Logo of a company" alt="Logo of a company" />
<img src="66.jpg" width="400" height="400" title="Logo of a company" alt="Logo of a company" />


</marquee>

<br>
<br>
<br>
<h3 style="color: blue">Academic Partner</h3>


<p> <abbr title="WASHBURN UNIVERSITY">W...</abbr>
 <abbr title="Global INstitiute Managment">GIIM...</abbr>

 <abbr title="University Utara Malaysia ">UUM...</abbr>
 <abbr title="Center for Technical and Higher Education University">CEYTS... </abbr></p>
<h5 align="left"><b>University of Education (UE)<br>
 408/1, Kuratoli, Khilkhet,<br>
Dhaka 1229, Bangladesh<br>
 info@aiub.edu <b></h5>

  </body>
  </html>