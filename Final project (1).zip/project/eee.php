<?php include('navbar.php');?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>eee</title>
</head>
<body>
	<h1>Electrical engineering</h1><br>
	Electrical and computer engineering" redirects here. For contents about computer engineering, see Computer engineering.
Electrical engineering
Umspannwerk-Pulverdingen 380kV-Trennschalter.jpg
Occupation
Names	Electrical engineer
Activity sectors	Electronics, electrical circuits, electromagnetics, power engineering, electrical machines, telecommunication, control systems, signal processing, optics, photonics
Description
Competencies	Technical knowledge, management skills, design (see also Glossary of electrical and electronics engineering)
Fields of
employment	Technology, science, exploration, military, industry
Electrical engineering is an engineering discipline concerned with the study, design, and application of equipment, devices, and systems which use electricity, electronics, and electromagnetism. It emerged as an identifiable occupation in the latter half of the 19th century after commercialization of the electric telegraph, the telephone, and electrical power generation, distribution, and use.<br>

Electrical engineering is now divided into a wide range of different fields, including computer engineering, systems engineering, power engineering, telecommunications, radio-frequency engineering, signal processing, instrumentation, photovoltaic cells, electronics, and optics and photonics. Many of these disciplines overlap with other engineering branches, spanning a huge number of specializations including hardware engineering, power electronics, electromagnetics and waves, microwave engineering, nanotechnology, electrochemistry, renewable energies, mechatronics/control, and electrical materials science.[a]<br>

Electrical engineers typically hold a degree in electrical engineering or electronic engineering. Practising engineers may have professional certification and be members of a professional body or an international standards organization. These include the International Electrotechnical Commission (IEC), the Institute of Electrical and Electronics Engineers (IEEE) and the Institution of Engineering and Technology (IET) (formerly the IEE).<br>

Electrical engineers work in a very wide range of industries and the skills required are likewise variable. These range from circuit theory to the management skills of a project manager. The tools and equipment that an individual engineer may need are similarly variable, ranging from a simple voltmeter to sophisticated design and manufacturing software.


</body>
</html>