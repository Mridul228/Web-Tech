<!DOCTYPE HTML>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>UE Homepage</title>

<link rel="stylesheet" type="text/css" href="homepage.css">

 <style>
* {
  box-sizing: border-box;
}

}</style>
</head>

<body>
<div class="link">
  <h3><p align="right">
    <a href="HomePage.php">Homepage    </a>
<p align="left">
<a href="ContactUs.php">Contact Us     </a>
<p align="left">
<a href="ApplyNow.php">Apply</a>
<p align="right">
<a  href="login.php">Login</a>
<p align="Center">
<a href="Notice.php">Notice</a>
<a href="aboutus.php">About Us</a>
<a href="feedback.php">Feedback    </a>
<p align="left">
  <a href="academic.php">Academic   </a>
<p align="left">
<br></h3></p></h3></div><br>

  </body>
  </html>
