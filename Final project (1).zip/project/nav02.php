<!DOCTYPE HTML>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>UE Homepage</title>

<link rel="stylesheet" type="text/css" href="homepage.css">

 <style>
* {
  box-sizing: border-box;
}

}</style>
</head>

<body>
<div class="link">
  <h3><p align="right">
    <a href="home1.php">মূল পেজ     </a>
<p align="left">
<a href="wwork.php">কাজের সময়সূচী     </a>
<p align="left">
<a href="wfee.php">বেতন</a>

<a href="wbwork.php">বাকি কাজ</a>
<a href="wprofile.php">প্রোফাইল   </a>
<a href="weditprofile.php">প্রোফাইল সম্পাদনা  </a>
<a style="float:right" href="login.php">প্রস্থান  </a>
<p align="left">
 
<br></h3></p></h3></div><br>

  </body>
  </html>
