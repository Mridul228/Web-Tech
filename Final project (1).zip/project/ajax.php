 
 <?php include('Faclog.php');?><ul>
       

         <table border = "15" align="center" >

             

            <tr>
                <td> <h1 >  <a href="Ballinfo.html">All Student in section (Q)</a>  </h1> </td>
            </tr> 
             <tr>
                <td> <h1>   Show all students in Section (Q)</a>  </h1> </td>
            </tr> 
             <tr>
                <td> <h1>  <a href="sstudent.php">Search Students In Section (Q)</a>  </h1> </td>
            </tr> 
             
        
         
            <tr>
                <td> <h1>  <a href="faclog2nd.php">Back to previous Page</a>  </h1> </td>
            </tr> 
            

        
    </ul
     