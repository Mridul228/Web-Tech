<?php include('nav02.php');?>
<!DOCTYPE html>



<head>



<title> Course information Page </title>
<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<link rel="stylesheet" type="text/css" href="homepage.css">
</head>
<body>
<div class="ww">
<h1 align="center"> Class Information </h1>

</div><br><br>
<div class="bb">
<table align ="center" border="1" style="border-collapse:collapse">
<tr>
<th>মাস</th>
<th>মাসিক বেতন</th>
<th>বেতন ক্লিয়ার</th>
<th>ওভার টাইম</th>
<th>বেতন বাকি</th>



</tr>



<tr>
<td>জানুয়ারি</td>
<td>৩০০০</td>
<td>২৫০০</td>
<td>০</td>
<td>৫০০</td>
</tr>



<tr>
<td>ফেব্রুয়ারী</td>
<td>৫০০০</td>
<td>৩০০০</td>
<td>২০০</td>
<td>২২০০</td>
</tr>



<tr>
<td>মার্চ</td>
<td>৪৫০০</td>
<td>২৫০০</td>
<td>৩০০</td>
<td>১৮০০</td>



</tr><tr>
<td>এপ্রিল</td>
<td>৩০০০</td>
<td>৩০০০</td>
<td>০</td>
<td>০</td>

</tr>



<tr>
<td>মে</td>
<td>৭০০০</td>
<td>৫০০০</td>
<td>৫০০</td>
<td>২৫০০</td>



<tr>
<td>জুন</td>
<td>৩০০০</td>
<td>২৫০০</td>
<td>০</td>
<td>৫০০</td>
</tr>
<tr>
<td>জুলাই</td>
<td>২০০০</td>
<td>১০০০</td>
<td>১০০০</td>
<td>১০০০</td>
</tr>
</table></div>
</button><br><br>
<button><a href="login.php">logout</a></button></h2>
</body></html>