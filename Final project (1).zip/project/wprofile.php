<?php include('nav02.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>View Profile</title>

<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">


</head>
<body >

<img src="ayesha.png" width="150" height="160">
<h4>Name :  Most. Kaniz Ayesha  </h4>
<h4> Email : kanizayesha1999@gmail.com</h4>
<h4> Phone No  : 01793872565</h4>
<h4>Present Address : Basundhara, Dhaka</h4>
<h4>Permanent address : Rangpur</h4>
<h4>Date of Birth : 29/08/1971</h4>
<br>
<a> Change Profile </a><br><br>
<a> Change Password </a><br><br>
<a href="HomePage.php"> Log out </a><br><br>
<a href="faclog2nd.php"> Go Back To Dashboard </a>
</body>

</html>












</body>
</html>