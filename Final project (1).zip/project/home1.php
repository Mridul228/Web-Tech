<?php include('nav02.php');?>
<!DOCTYPE html>

<html>
<head>
<title> Faculty Home Page  </title>
<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<link rel="stylesheet" type="text/css" href="homepage.css">
</head> 
 <body>
    
 <div class="hello"> 
   
<h1 text align="center">হ্যালো ওয়ার্কার্স ইউই পোর্টালে স্বাগতম </h1> </div><br>

  
<div class="uni">
<marquee direction="left" behavior="alternate" >

<h1 >University of Education</marquee></a></h1></div><br>
<h1>
<div class="an"> <marquee direction="right" behavior="alternate" >
-An Invesment in Knowledge pays the best interest</a></h1>
  <img src="77.jpg" width="60" height="60" title="Logo of a company" alt="Logo of a company" />
  
</marquee></div><br><br> 
    

    <div class="table">
        <table border = "15" align="center" >

             

            <tr>
                <td> <h5 style= " background-color: blue;">  <a href="wwork.php">কাজের সময়সূচী</a>  </h5> </td>
            </tr> 

            <tr>
                <td> <h5 style= " background-color: thistle;  ">  <a href="wfee.php"> বেতন</a>  </h5> </td>
            </tr> 
            

            <tr>
                <td> <h5 style= " background-color: thistle;">  <a href="wbwork.php">বাকি কাজ</a>  </h5> </td>
            </tr> 
 <tr>
                <td> <h5 style= " background-color: thistle;">  <a href="wprofile.php">প্রোফাইল</a>  </h5> </td>
            </tr> 
       <tr>
                <td> <h5 style= " background-color: thistle;">  <a href="weditprofile.php">প্রোফাইল সম্পাদনা </a>  </h5> </td>
            </tr> 
        </table>
</div>
<div> <a href="facultylog.php">প্রস্থান</a></div>
       
    
</body> 

</html>
<style>
    body{
background: url(a1.png);
background-attachment: fixed;
background-size: cover;
}


    