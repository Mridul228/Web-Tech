<!DOCTYPE HTML>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin page</title>

<link rel="stylesheet" type="text/css" href="adminpage.css">

 <style>
* {
  box-sizing: border-box;
}

}</style>
</head>

<body>
<div class="link">
  <h3><p align="right">
<a href="vadminprofile.php">My Profile    </a>
<p align="left">
<a href="faclog2nd.php">Faculty page</a>
<p align="right">
<a  href="dashboard.php">Student Page</a>
<p align="Center">
<a href="home1.php">Workers page</a>
<a href="post.php">Update notice</a>
<a href="index.php">Employeress details</a>
<a style="float:right" href="login.php">Log out   </a>
<p align="left">
<br></h3></p></h3></div><br>

  </body>
  </html>