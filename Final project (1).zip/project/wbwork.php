<?php include('nav02.php');?>
<!DOCTYPE html>

<html>
<head>

<title> Course information Page  </title>
<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<link rel="stylesheet" type="text/css" href="homepage.css">
</head> 
 <body>
    <div class="ww">
    <h1 align="center"> বাকি কাজের সময়সূচী </h1>
    
</div><br><br>
<div class="bb">
<table align ="center" border="1" style="border-collapse:collapse"> 
<tr>
<th>কাজ নং</th>
<th>কাজের নাম</th>
<th>দিনের নাম</th>
<th>রুম নং</th>
<th>সময়</th>


</tr>

<tr>
    <td>০০১</td>
    <td>রুম পরিষ্কার</td>
    <td>রবিবার</td>
    <td>৫০০১</td>
    <td>৮.০০ থেকে ৯.০০ টা</td>
  </tr>

<tr>
    <td>০০২</td>
    <td>রুম পরিষ্কার</td>
    <td>সঅম্বার</td>
    <td>৫০০২</td>
    <td>১০ টা থেকে ১১ টা</td>
  </tr>

<tr>
    <td>০০৩</td>
    <td>বারান্দা পরিষ্কার</td>
    <td> মঙ্গলবার</td>
    <td> ১০০০১</td>
    <td>২ টা থেকে ৩ টা</td>

  </tr><tr>
<td>২০০১</td>
    <td> ডেস্ক পরিশকার</td>
    <td>বুধবার</td>
    <td> ৩০০১</td>
    <td>১ টা থেকে ৩ টা</td></tr>
    <tr>
    <td>৪০০১</td>
    <td> কাজ</td>
    <td>শনিবার</td>
    <td>৫০০১</td>
    <td> ১ টা থেকে ২ টা</td>
  </tr>

<tr>
    <td>৪০১২</td>
    <td>কাজ</td>
    <td>শনিবার</td>
    <td>৫০০১</td>
    <td>৩ টা থেকে ৪ টা</td>
  </tr>


</table></div>
<h2 align="right"><button><a href="faclogfirst.php">Go to options</a>
</button><br><br>
<button><a href="facultylog.php">logout</a></button></h2>
</body></html>