<!DOCTYPE html>
<html>
<head>
<style>
ul {
  text-align: center;
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 20px 30px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #04AA6D;
}
h1 {text-align: center;}

</style>
</head>
<body>
 <title>No</title>
 <h1>Header</h1><br>

<ul>
  <li><a href="#home">Link</a></li>
  <li><a href="#news">Link</a></li>
  <li><a href="#contact">Link</a></li>
  
</ul>

</body>
</html>

