<!DOCTYPE HTML>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>UE Homepage</title>

<link rel="stylesheet" type="text/css" href="homepage.css">

 <style>
* {
  box-sizing: border-box;
}

}</style>
</head>

<body>
<div class="link">
  <h3><p align="right">
    <a href="dashboard.php">Dashboard    </a>
<p align="left">
<a href="mycourse.php">My course     </a>
<p align="left">
<a href="courseresult.php">Course result</a>
<p align="Center">
<a href="Notice.php">Notice</a>
<a href="updateprofile.php">Update Profile</a>
<a href="viewprofile1.php">View Profile   </a>
<p align="left">
  <a style="float:right" href="login.php">Log out   </a>
<p align="left">
 
<br></h3></p></h3></div><br>

  </body>
  </html>
